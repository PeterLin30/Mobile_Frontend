import 'package:flutter/material.dart';
import 'package:lucide_icons_flutter/lucide_icons.dart';

import 'chat_page.dart';
import 'profile_page.dart';
import 'voucher_page.dart';
import 'news_page.dart';
import 'promo_detail_page.dart';

const Color primaryColor = Color(0xFF5CC8CC);
const Color lightCyan = Color(0xFFC8F1F3);
const Color textColor = Color(0xFF202124);

class ServiceItem {
  final String title;
  final IconData icon;

  const ServiceItem(this.title, this.icon);
}

class PromoItem {
  final String title;
  final String subtitle;
  final IconData icon;

  const PromoItem(this.title, this.subtitle, this.icon);
}

class NewsItem {
  final String title;
  final String date;
  final IconData icon;

  const NewsItem(this.title, this.date, this.icon);
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int _selectedIndex = 0;

  final List<ServiceItem> _services = const [
    ServiceItem('Mobile', LucideIcons.smartphone),
    ServiceItem('Web', LucideIcons.globe),
    ServiceItem('Cyber', LucideIcons.shieldCheck),
    ServiceItem('Graphic', LucideIcons.palette),
    ServiceItem('Digital', LucideIcons.megaphone),
    ServiceItem('Bisnis', LucideIcons.store),
    ServiceItem('See All', LucideIcons.grid2x2),
  ];

  final List<PromoItem> _promos = const [
    PromoItem(
      'Promo UMKM',
      'Penawaran menarik untuk usahamu',
      Icons.storefront_rounded,
    ),
    PromoItem(
      'Paket Hemat',
      'Solusi digital lebih terjangkau',
      Icons.local_offer_rounded,
    ),
    PromoItem(
      'Promo Desain',
      'Tingkatkan identitas bisnismu',
      Icons.design_services_rounded,
    ),
  ];

  final List<NewsItem> _news = const [
    NewsItem(
      'Tips Mengembangkan Bisnis UMKM di Era Digital',
      '28 Oktober 2026',
      Icons.trending_up_rounded,
    ),
    NewsItem(
      'Pentingnya Website untuk Bisnis Lokal',
      '25 Oktober 2026',
      Icons.language_rounded,
    ),
    NewsItem(
      'Strategi Branding agar UMKM Lebih Dikenal',
      '22 Oktober 2026',
      Icons.lightbulb_outline_rounded,
    ),
  ];

  void _showMessage(String message) {
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(
        SnackBar(content: Text(message), behavior: SnackBarBehavior.floating),
      );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // IndexedStack keeps each page's state while switching tabs.
      body: SafeArea(
        bottom: false,
        child: IndexedStack(
          index: _selectedIndex,
          children: [
            _buildHomeContent(),
            const ChatPage(),
            _buildActivityPage(),
            const ProfilePage(),
          ],
        ),
      ),
      bottomNavigationBar: _buildBottomNavigation(),
    );
  }

  Widget _buildActivityPage() {
    return const Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.receipt_long_rounded, size: 60, color: primaryColor),
          SizedBox(height: 16),
          Text(
            'Aktivitas',
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: textColor,
            ),
          ),
          SizedBox(height: 8),
          Text(
            'Riwayat aktivitas kamu akan muncul di sini.',
            style: TextStyle(color: Colors.grey),
          ),
        ],
      ),
    );
  }

  Widget _buildHomeContent() {
    return CustomScrollView(
      slivers: [
        SliverPadding(
          padding: const EdgeInsets.fromLTRB(20, 14, 20, 0),
          sliver: SliverList(
            delegate: SliverChildListDelegate([
              const Text(
                'Welcome,',
                style: TextStyle(fontSize: 19, color: textColor),
              ),
              const Text(
                'Pengguna MikroHub',
                style: TextStyle(
                  fontSize: 18,
                  color: textColor,
                  fontWeight: FontWeight.w500,
                ),
              ),

              const SizedBox(height: 16),

              // Services
              _buildServices(),

              const SizedBox(height: 22),

              _buildSectionTitle('Promo'),

              const SizedBox(height: 10),

              _buildPromos(),

              const SizedBox(height: 16),

              _buildVoucherButton(),

              const SizedBox(height: 22),

              Row(
                children: [
                  const Expanded(
                    child: Text(
                      'News',
                      style: TextStyle(
                        fontSize: 21,
                        color: textColor,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                  OutlinedButton(
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => const NewsPage(),
                        ),
                      );
                    },
                    style: OutlinedButton.styleFrom(
                      foregroundColor: primaryColor,
                      side: const BorderSide(color: lightCyan),
                      minimumSize: const Size(0, 34),
                    ),
                    child: const Text(
                      'SEE ALL',
                      style: TextStyle(fontSize: 11),
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 8),
            ]),
          ),
        ),

        SliverPadding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          sliver: SliverList(
            delegate: SliverChildBuilderDelegate((context, index) {
              return Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: _buildNewsCard(_news[index]),
              );
            }, childCount: _news.length),
          ),
        ),

        const SliverToBoxAdapter(child: SizedBox(height: 24)),
      ],
    );
  }

  Widget _buildSectionTitle(String title) {
    return Text(
      title,
      style: const TextStyle(
        fontSize: 16,
        color: textColor,
        fontWeight: FontWeight.w500,
      ),
    );
  }

  // SERVICES: komponen bawaan Flutter.

  Widget _buildServices() {
    return Container(
      height: 120,
      decoration: BoxDecoration(
        color: lightCyan,
        borderRadius: BorderRadius.circular(4),
      ),
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        physics: const BouncingScrollPhysics(),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
        itemCount: _services.length,
        separatorBuilder: (context, index) => const SizedBox(width: 16),
        itemBuilder: (context, index) {
          final service = _services[index];
          final bool isSeeAll = service.title == 'See All';

          return SizedBox(
            width: 60,
            child: InkWell(
              borderRadius: BorderRadius.circular(12),
              onTap: () {
                if (isSeeAll) {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => AllServicesPage(
                        services: _services
                            .where((item) => item.title != 'See All')
                            .toList(),
                      ),
                    ),
                  );
                } else {
                  _showMessage('Layanan ${service.title} dipilih');
                }
              },
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  CircleAvatar(
                    radius: 25,
                    backgroundColor: Colors.white,
                    foregroundColor: const Color(0xFF616D70),
                    child: Icon(service.icon, size: 25),
                  ),
                  const SizedBox(height: 7),
                  Text(
                    service.title,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontSize: 12, color: textColor),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  // PROMO: kartu horizontal yang bisa digeser.

  Widget _buildPromos() {
    return SizedBox(
      height: 120,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        physics: const BouncingScrollPhysics(),
        padding: const EdgeInsets.only(right: 4),
        itemCount: _promos.length,
        separatorBuilder: (context, index) => const SizedBox(width: 10),
        itemBuilder: (context, index) {
          final promo = _promos[index];

          return SizedBox(
            width: 150,
            child: Material(
              color: lightCyan,
              borderRadius: BorderRadius.circular(6),
              clipBehavior: Clip.antiAlias,
              child: InkWell(
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => PromoDetailPage(
                        title: promo.title,
                        subtitle: promo.subtitle,
                        icon: promo.icon,
                      ),
                    ),
                  );
                },

                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Icon(
                        promo.icon,
                        size: 27,
                        color: const Color(0xFF397E82),
                      ),
                      const Spacer(),
                      Text(
                        promo.title,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          fontSize: 13,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        promo.subtitle,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(fontSize: 11),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  // VOUCHER
  Widget _buildVoucherButton() {
    return Material(
      color: const Color(0xFF9CE3E7),
      borderRadius: BorderRadius.circular(5),
      elevation: 2,
      child: InkWell(
        borderRadius: BorderRadius.circular(5),
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => const VoucherPage()),
          );
        },
        child: const SizedBox(
          height: 42,
          child: Padding(
            padding: EdgeInsets.symmetric(horizontal: 12),
            child: Row(
              children: [
                Icon(Icons.confirmation_number_outlined, size: 23),
                SizedBox(width: 6),
                Expanded(
                  child: Text(
                    'Voucher Coupon',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 14),
                  ),
                ),
                Icon(Icons.arrow_circle_right_outlined, size: 25),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // NEWS

  Widget _buildNewsCard(NewsItem news) {
    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(8),
      child: InkWell(
        borderRadius: BorderRadius.circular(8),
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => HomeNewsDetailPage(news: news),
            ),
          );
        },
        child: Padding(
          padding: const EdgeInsets.all(10),
          child: Row(
            children: [
              Container(
                width: 64,
                height: 64,
                decoration: BoxDecoration(
                  color: lightCyan,
                  borderRadius: BorderRadius.circular(6),
                ),
                child: Icon(
                  news.icon,
                  color: const Color(0xFF397E82),
                  size: 30,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      news.title,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w500,
                        color: textColor,
                      ),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      news.date,
                      style: const TextStyle(fontSize: 11, color: Colors.grey),
                    ),
                  ],
                ),
              ),
              const Icon(Icons.chevron_right, color: Colors.grey),
            ],
          ),
        ),
      ),
    );
  }

  // BOTTOM NAVIGATION
  Widget _buildBottomNavigation() {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border(
          top: BorderSide(
            color: primaryColor.withValues(alpha: 0.8),
            width: 1.2,
          ),
        ),
      ),
      child: SafeArea(
        top: false,
        child: SizedBox(
          height: 64,
          child: Stack(
            clipBehavior: Clip.none,
            alignment: Alignment.center,
            children: [
              Row(
                children: [
                  _buildNavItem(0, Icons.home_rounded, 'Home'),
                  _buildNavItem(1, Icons.chat_rounded, 'Pesan'),
                  const SizedBox(width: 60),
                  _buildNavItem(2, Icons.receipt_long_rounded, 'Aktivitas'),
                  _buildNavItem(3, Icons.person_rounded, 'Profil'),
                ],
              ),
              Positioned(
                top: -22,
                child: Material(
                  color: const Color(0xFF9CE3E7),
                  shape: const CircleBorder(),
                  child: InkWell(
                    customBorder: const CircleBorder(),
                    onTap: () {
                      _showMessage('Menu utama MikroHub');
                    },
                    child: Container(
                      width: 54,
                      height: 54,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(color: Colors.white, width: 3),
                      ),
                      child: const Icon(
                        Icons.grid_view_rounded,
                        color: Colors.white,
                        size: 27,
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildNavItem(int index, IconData icon, String label) {
    final bool selected = _selectedIndex == index;

    return Expanded(
      child: InkWell(
        onTap: () {
          setState(() {
            _selectedIndex = index;
          });
        },
        child: SizedBox(
          height: 64,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                icon,
                size: 25,
                color: selected ? primaryColor : const Color(0xFFD2D4D5),
              ),
              const SizedBox(height: 2),
              Text(
                label,
                style: TextStyle(
                  fontSize: 9,
                  color: selected ? primaryColor : const Color(0xFF9EA1A3),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class HomeNewsDetailPage extends StatelessWidget {
  final NewsItem news;

  const HomeNewsDetailPage({super.key, required this.news});

  String get articleContent {
    switch (news.title) {
      case 'Tips Mengembangkan Bisnis UMKM di Era Digital':
        return 'Perkembangan teknologi digital memberikan '
            'kesempatan bagi pelaku UMKM untuk menjangkau lebih '
            'banyak pelanggan. Pemanfaatan media sosial, pemasaran '
            'digital, dan layanan online dapat membantu bisnis '
            'meningkatkan visibilitasnya.\n\n'
            'Pelaku usaha dapat memulai dengan menentukan target '
            'pasar, membuat konten yang relevan, menjaga kualitas '
            'produk, serta memberikan pelayanan yang baik kepada '
            'pelanggan. Evaluasi secara berkala juga penting untuk '
            'mengetahui strategi yang paling efektif.';

      case 'Pentingnya Website untuk Bisnis Lokal':
        return 'Website dapat menjadi pusat informasi resmi bagi '
            'bisnis lokal. Melalui website, pelanggan dapat '
            'mengenal produk, melihat informasi layanan, serta '
            'menemukan cara menghubungi pemilik usaha.\n\n'
            'Website yang informatif dan mudah digunakan dapat '
            'membantu meningkatkan kepercayaan pelanggan. Pastikan '
            'informasi produk, kontak, harga, dan jam operasional '
            'diperbarui secara berkala.';

      case 'Strategi Branding agar UMKM Lebih Dikenal':
        return 'Branding membantu bisnis memiliki identitas yang '
            'mudah dikenali oleh pelanggan. Identitas tersebut '
            'dapat dibangun melalui nama merek, logo, warna, gaya '
            'komunikasi, dan kualitas pelayanan yang konsisten.\n\n'
            'UMKM sebaiknya memahami karakteristik target pasar '
            'sebelum menentukan strategi branding. Gunakan identitas '
            'yang konsisten pada kemasan, media sosial, dan materi '
            'promosi agar pelanggan lebih mudah mengingat bisnis.';

      default:
        return 'Baca informasi dan tips berikut untuk membantu '
            'mengembangkan bisnis serta memahami peluang di era '
            'digital.\n\n'
            'Sesuaikan strategi dengan kebutuhan usaha, pahami '
            'pelanggan, dan lakukan evaluasi secara berkala agar '
            'pengembangan bisnis dapat berjalan lebih terarah.';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F7FA),
      appBar: AppBar(
        title: const Text('Detail Berita'),
        backgroundColor: primaryColor,
        foregroundColor: Colors.white,
        elevation: 0,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: double.infinity,
              height: 180,
              decoration: BoxDecoration(
                color: lightCyan,
                borderRadius: BorderRadius.circular(16),
              ),
              child: Icon(news.icon, size: 80, color: const Color(0xFF397E82)),
            ),
            const SizedBox(height: 20),
            Text(
              news.date,
              style: const TextStyle(color: Colors.grey, fontSize: 12),
            ),
            const SizedBox(height: 10),
            Text(
              news.title,
              style: const TextStyle(
                color: textColor,
                fontSize: 23,
                fontWeight: FontWeight.bold,
                height: 1.4,
              ),
            ),
            const SizedBox(height: 20),
            const Divider(),
            const SizedBox(height: 12),
            Text(
              articleContent,
              style: const TextStyle(
                color: textColor,
                fontSize: 15,
                height: 1.8,
              ),
              textAlign: TextAlign.justify,
            ),
            const SizedBox(height: 30),
            SizedBox(
              width: double.infinity,
              child: FilledButton.icon(
                onPressed: () => Navigator.pop(context),
                style: FilledButton.styleFrom(
                  backgroundColor: primaryColor,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 14),
                ),
                icon: const Icon(Icons.arrow_back_rounded),
                label: const Text('Kembali ke Beranda'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class AllServicesPage extends StatelessWidget {
  final List<ServiceItem> services;

  const AllServicesPage({super.key, required this.services});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F7FA),
      appBar: AppBar(
        title: const Text('Semua Layanan'),
        backgroundColor: primaryColor,
        foregroundColor: Colors.white,
      ),
      body: GridView.builder(
        padding: const EdgeInsets.all(20),
        itemCount: services.length,
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 3,
          crossAxisSpacing: 12,
          mainAxisSpacing: 12,
          childAspectRatio: 0.85,
        ),
        itemBuilder: (context, index) {
          final service = services[index];

          return Material(
            color: Colors.white,
            borderRadius: BorderRadius.circular(12),
            child: InkWell(
              borderRadius: BorderRadius.circular(12),
              onTap: () {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text('Layanan ${service.title} dipilih'),
                    behavior: SnackBarBehavior.floating,
                  ),
                );
              },
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  CircleAvatar(
                    radius: 25,
                    backgroundColor: lightCyan,
                    child: Icon(
                      service.icon,
                      color: const Color(0xFF397E82),
                      size: 26,
                    ),
                  ),
                  const SizedBox(height: 10),
                  Text(
                    service.title,
                    textAlign: TextAlign.center,
                    style: const TextStyle(fontSize: 12, color: textColor),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
